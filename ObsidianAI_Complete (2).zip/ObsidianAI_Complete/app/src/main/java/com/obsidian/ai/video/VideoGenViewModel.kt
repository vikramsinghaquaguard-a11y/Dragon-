package com.obsidian.ai.video

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.obsidian.ai.data.ApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class VideoGenState {
    object Idle : VideoGenState()
    data class Generating(val elapsedSeconds: Int) : VideoGenState()
    data class Success(val filePath: String) : VideoGenState()
    data class Error(val message: String) : VideoGenState()
}

class VideoGenViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = VideoGenRepository()
    private val apiKeyStore = ApiKeyStore(application)

    private val _state = MutableStateFlow<VideoGenState>(VideoGenState.Idle)
    val state: StateFlow<VideoGenState> = _state

    fun generate(prompt: String, aspectRatio: String) {
        if (prompt.isBlank()) return
        _state.value = VideoGenState.Generating(0)

        viewModelScope.launch {
            try {
                // Reuses the same Gemini API key already entered for chat/image use.
                val apiKey = apiKeyStore.geminiKey.first()
                if (apiKey.isBlank()) {
                    _state.value = VideoGenState.Error("Add your Gemini API key in Settings first")
                    return@launch
                }

                val operationName = withContext(Dispatchers.IO) {
                    repository.startGeneration(prompt, apiKey, aspectRatio)
                }

                var elapsed = 0
                while (true) {
                    delay(10_000)
                    elapsed += 10
                    _state.value = VideoGenState.Generating(elapsed)

                    val status = withContext(Dispatchers.IO) {
                        repository.pollOperation(operationName, apiKey)
                    }

                    when (status) {
                        is VideoOperationStatus.Pending -> {
                            // keep looping
                        }
                        is VideoOperationStatus.Error -> {
                            _state.value = VideoGenState.Error(status.message)
                            return@launch
                        }
                        is VideoOperationStatus.Done -> {
                            val bytes = withContext(Dispatchers.IO) {
                                repository.downloadVideoBytes(status.videoUri, apiKey)
                            }
                            val outputDir = File(
                                getApplication<Application>().getExternalFilesDir(null),
                                "videos"
                            )
                            outputDir.mkdirs()
                            val outputFile = File(outputDir, "obsidian_ai_${System.currentTimeMillis()}.mp4")
                            withContext(Dispatchers.IO) {
                                outputFile.writeBytes(bytes)
                            }
                            _state.value = VideoGenState.Success(outputFile.absolutePath)
                            return@launch
                        }
                    }
                }
            } catch (e: Exception) {
                _state.value = VideoGenState.Error(e.message ?: "Something went wrong")
            }
        }
    }

    fun reset() {
        _state.value = VideoGenState.Idle
    }
}
