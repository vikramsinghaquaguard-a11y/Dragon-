package com.obsidian.ai.data.repository

sealed class AIResult {
    data class Success(val provider: String, val text: String, val elapsedMs: Long) : AIResult()
    data class Failure(val provider: String, val error: String) : AIResult()
}

interface AIRepository {
    val providerName: String
    suspend fun ask(prompt: String, apiKey: String): AIResult
}
