package com.obsidian.ai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.obsidian.ai.character.ImageGenState
import com.obsidian.ai.character.ImageGenViewModel
import com.obsidian.ai.persona.CharacterGender
import com.obsidian.ai.wallpaper.launchCharacterWallpaperPicker
import android.graphics.BitmapFactory
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterCreatorScreen(
    viewModel: ImageGenViewModel,
    initialGender: CharacterGender,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    var gender by remember { mutableStateOf(initialGender) }
    var styleDescription by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Character Look") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Text("Gender", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(4.dp))
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = gender == CharacterGender.MALE,
                    onClick = { gender = CharacterGender.MALE },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Male") }
                SegmentedButton(
                    selected = gender == CharacterGender.FEMALE,
                    onClick = { gender = CharacterGender.FEMALE },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Female") }
            }
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = styleDescription,
                onValueChange = { styleDescription = it },
                label = { Text("Style (optional)") },
                placeholder = { Text("e.g. short brown hair, casual hoodie, anime style") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(12.dp))

            val isBusy = state is ImageGenState.Generating
            Button(
                onClick = { viewModel.generate(gender, styleDescription) },
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Generate portrait")
            }

            Spacer(modifier = Modifier.height(20.dp))

            when (val current = state) {
                is ImageGenState.Idle -> {
                    Text(
                        "Generates a front-facing character portrait, used on your " +
                            "home screen wallpaper.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is ImageGenState.Generating -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generating...")
                    }
                }
                is ImageGenState.Error -> {
                    Text(current.message, color = MaterialTheme.colorScheme.error)
                }
                is ImageGenState.Success -> {
                    val bitmap = remember(current.filePath) {
                        BitmapFactory.decodeFile(current.filePath)?.asImageBitmap()
                    }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap,
                            contentDescription = "Generated character",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(280.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { launchCharacterWallpaperPicker(context) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Set as home screen character")
                    }
                }
            }
        }
    }
}
