package com.obsidian.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.obsidian.ai.auth.AuthViewModel
import com.obsidian.ai.character.ImageGenViewModel
import com.obsidian.ai.ui.ChatScreen
import com.obsidian.ai.ui.CharacterCreatorScreen
import com.obsidian.ai.ui.LoginScreen
import com.obsidian.ai.ui.SettingsScreen
import com.obsidian.ai.ui.VideoGenScreen
import com.obsidian.ai.video.VideoGenViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val authViewModel: AuthViewModel by viewModels()
    private val videoGenViewModel: VideoGenViewModel by viewModels()
    private val imageGenViewModel: ImageGenViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "login") {
                        composable("login") {
                            LoginScreen(
                                authViewModel = authViewModel,
                                onSignedIn = {
                                    navController.navigate("chat") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("chat") {
                            ChatScreen(
                                viewModel = viewModel,
                                onOpenSettings = { navController.navigate("settings") },
                                onOpenVideoGen = { navController.navigate("video") },
                                onOpenCharacterCreator = { navController.navigate("character") }
                            )
                        }
                        composable("character") {
                            val gender by viewModel.personaStore.gender.collectAsState(
                                initial = com.obsidian.ai.persona.CharacterGender.MALE
                            )
                            CharacterCreatorScreen(
                                viewModel = imageGenViewModel,
                                initialGender = gender,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("video") {
                            VideoGenScreen(
                                viewModel = videoGenViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
