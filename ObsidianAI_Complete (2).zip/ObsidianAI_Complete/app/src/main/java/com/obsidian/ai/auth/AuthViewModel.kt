package com.obsidian.ai.auth

import android.app.Application
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    object SignedOut : AuthState()
    object Loading : AuthState()
    data class SignedIn(val email: String?) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val auth = FirebaseAuth.getInstance()

    private val _authState = MutableStateFlow<AuthState>(
        if (auth.currentUser != null) AuthState.SignedIn(auth.currentUser?.email) else AuthState.SignedOut
    )
    val authState: StateFlow<AuthState> = _authState

    /**
     * Paste the "Web client ID" from Firebase Console -> Authentication ->
     * Sign-in method -> Google -> Web SDK configuration here.
     */
    private val webClientId = "PASTE_YOUR_FIREBASE_WEB_CLIENT_ID_HERE"

    fun signUpWithEmail(email: String, password: String) {
        _authState.value = AuthState.Loading
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                _authState.value = AuthState.SignedIn(auth.currentUser?.email)
            }
            .addOnFailureListener { e ->
                _authState.value = AuthState.Error(e.message ?: "Sign up failed")
            }
    }

    fun signInWithEmail(email: String, password: String) {
        _authState.value = AuthState.Loading
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                _authState.value = AuthState.SignedIn(auth.currentUser?.email)
            }
            .addOnFailureListener { e ->
                _authState.value = AuthState.Error(e.message ?: "Sign in failed")
            }
    }

    fun signInWithGoogle(context: android.content.Context) {
        _authState.value = AuthState.Loading
        viewModelScope.launch {
            try {
                val credentialManager = CredentialManager.create(context)

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(webClientId)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(context, request)
                val credential = result.credential

                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val firebaseCredential = GoogleAuthProvider.getCredential(
                        googleIdTokenCredential.idToken, null
                    )
                    auth.signInWithCredential(firebaseCredential)
                        .addOnSuccessListener {
                            _authState.value = AuthState.SignedIn(auth.currentUser?.email)
                        }
                        .addOnFailureListener { e ->
                            _authState.value = AuthState.Error(e.message ?: "Google sign-in failed")
                        }
                } else {
                    _authState.value = AuthState.Error("Unexpected credential type")
                }
            } catch (e: GoogleIdTokenParsingException) {
                _authState.value = AuthState.Error("Couldn't parse Google credential")
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Google sign-in failed")
            }
        }
    }

    fun signOut() {
        auth.signOut()
        _authState.value = AuthState.SignedOut
    }
}
