package com.obsidian.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.obsidian.ai.data.ApiKeyStore
import com.obsidian.ai.data.repository.AIRepository
import com.obsidian.ai.data.repository.AIResult
import com.obsidian.ai.data.repository.ClaudeRepository
import com.obsidian.ai.data.repository.GeminiRepository
import com.obsidian.ai.data.repository.OpenAIRepository
import com.obsidian.ai.persona.ConversationMemory
import com.obsidian.ai.persona.PersonaStore
import com.obsidian.ai.persona.buildPersonaPreamble
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val apiKeyStore = ApiKeyStore(application)
    val personaStore = PersonaStore(application)
    private val memory = ConversationMemory(application)

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val repositories: List<AIRepository> = listOf(
        OpenAIRepository(client),
        GeminiRepository(client),
        ClaudeRepository(client)
    )

    // Results arrive in this list in completion order -- fastest provider first.
    private val _results = MutableStateFlow<List<AIResult>>(emptyList())
    val results: StateFlow<List<AIResult>> = _results

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun ask(userText: String) {
        if (userText.isBlank()) return
        _results.value = emptyList()
        _isLoading.value = true

        viewModelScope.launch {
            val openAiKey = apiKeyStore.openAiKey.first()
            val geminiKey = apiKeyStore.geminiKey.first()
            val claudeKey = apiKeyStore.claudeKey.first()

            val keyMap = mapOf(
                "ChatGPT" to openAiKey,
                "Gemini" to geminiKey,
                "Claude" to claudeKey
            )

            // Build the persona + recent-memory preamble that gets prepended
            // to the raw question, so every provider answers "in character"
            // and with awareness of what you two just talked about.
            val name = personaStore.characterName.first()
            val gender = personaStore.gender.first()
            val shy = personaStore.shyMode.first()
            val recentExchanges = memory.recentExchanges()

            val preamble = buildPersonaPreamble(name, gender, shy)
            val historyBlock = memory.formatForPrompt(recentExchanges)
            val fullPrompt = "$preamble\n\n$historyBlock$userText"

            val resultsChannel = Channel<AIResult>(Channel.UNLIMITED)

            repositories.forEach { repo ->
                launch(Dispatchers.IO) {
                    val result = repo.ask(fullPrompt, keyMap[repo.providerName].orEmpty())
                    resultsChannel.send(result)
                }
            }

            var firstSuccessText: String? = null
            repeat(repositories.size) {
                val result = resultsChannel.receive()
                if (firstSuccessText == null && result is AIResult.Success) {
                    firstSuccessText = result.text
                }
                _results.value = _results.value + result
            }

            // Remember this exchange (using the fastest successful reply)
            // so the next question can reference it.
            firstSuccessText?.let { reply ->
                memory.addExchange(userText, reply)
            }

            _isLoading.value = false
        }
    }

    fun clearMemory() {
        viewModelScope.launch { memory.clear() }
    }
}
