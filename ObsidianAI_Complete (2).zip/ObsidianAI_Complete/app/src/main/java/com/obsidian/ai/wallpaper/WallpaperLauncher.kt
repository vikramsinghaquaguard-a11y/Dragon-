package com.obsidian.ai.wallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Opens Android's built-in "set live wallpaper" preview screen, pre-selected
 * to this app's character wallpaper.
 */
fun launchCharacterWallpaperPicker(context: Context) {
    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
    intent.putExtra(
        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
        ComponentName(context, CharacterWallpaperService::class.java)
    )
    context.startActivity(intent)
}
