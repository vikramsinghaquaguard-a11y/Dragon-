package com.obsidian.ai.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.obsidian.ai.video.VideoGenState
import com.obsidian.ai.video.VideoGenViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoGenScreen(viewModel: VideoGenViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    var prompt by remember { mutableStateOf("") }
    var portrait by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Video") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("Describe the video") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Portrait (9:16)")
                Spacer(modifier = Modifier.width(8.dp))
                Switch(checked = portrait, onCheckedChange = { portrait = it })
            }
            Spacer(modifier = Modifier.height(12.dp))

            val isBusy = state is VideoGenState.Generating
            Button(
                onClick = { viewModel.generate(prompt, if (portrait) "9:16" else "16:9") },
                enabled = prompt.isNotBlank() && !isBusy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Generate video")
            }

            Spacer(modifier = Modifier.height(20.dp))

            when (val current = state) {
                is VideoGenState.Idle -> {
                    Text(
                        "Generation usually takes 30 seconds to a few minutes.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is VideoGenState.Generating -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generating... ${current.elapsedSeconds}s elapsed")
                    }
                }
                is VideoGenState.Error -> {
                    Text(current.message, color = MaterialTheme.colorScheme.error)
                }
                is VideoGenState.Success -> {
                    Text("Video ready!")
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        val file = File(current.filePath)
                        val uri = FileProvider.getUriForFile(
                            context, "${context.packageName}.fileprovider", file
                        )
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "video/mp4")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(intent)
                    }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Play video")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(current.filePath, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
