package com.obsidian.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.obsidian.ai.MainViewModel
import com.obsidian.ai.persona.CharacterGender
import com.obsidian.ai.voice.LanguagePrefStore
import com.obsidian.ai.voice.SUPPORTED_LANGUAGES
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val store = viewModel.apiKeyStore
    val personaStore = viewModel.personaStore
    val languageStore = remember { LanguagePrefStore(context) }

    var openAiKey by remember { mutableStateOf("") }
    var geminiKey by remember { mutableStateOf("") }
    var claudeKey by remember { mutableStateOf("") }
    var characterName by remember { mutableStateOf("Obsidian") }

    LaunchedEffect(Unit) { store.openAiKey.collect { openAiKey = it; return@collect } }
    LaunchedEffect(Unit) { store.geminiKey.collect { geminiKey = it; return@collect } }
    LaunchedEffect(Unit) { store.claudeKey.collect { claudeKey = it; return@collect } }
    LaunchedEffect(Unit) { personaStore.characterName.collect { characterName = it; return@collect } }

    val currentGender by personaStore.gender.collectAsState(initial = CharacterGender.MALE)
    val shyMode by personaStore.shyMode.collectAsState(initial = false)
    val currentLanguageTag by languageStore.languageTag.collectAsState(initial = "en-US")
    var languageMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Text("Character", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = characterName,
                onValueChange = { characterName = it },
                label = { Text("Character name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))

            Text("Voice / gender", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(4.dp))
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = currentGender == CharacterGender.MALE,
                    onClick = { scope.launch { personaStore.saveGender(CharacterGender.MALE) } },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Male") }
                SegmentedButton(
                    selected = currentGender == CharacterGender.FEMALE,
                    onClick = { scope.launch { personaStore.saveGender(CharacterGender.FEMALE) } },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Female") }
            }
            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Shy personality", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Softer, shorter, more bashful replies",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = shyMode, onCheckedChange = { scope.launch { personaStore.saveShyMode(it) } })
            }
            Spacer(modifier = Modifier.height(12.dp))

            Text("Voice language", style = MaterialTheme.typography.labelLarge)
            Box {
                OutlinedButton(onClick = { languageMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(SUPPORTED_LANGUAGES.firstOrNull { it.tag == currentLanguageTag }?.label ?: "English (US)")
                }
                DropdownMenu(expanded = languageMenuExpanded, onDismissRequest = { languageMenuExpanded = false }) {
                    SUPPORTED_LANGUAGES.forEach { lang ->
                        DropdownMenuItem(
                            text = { Text(lang.label) },
                            onClick = {
                                languageMenuExpanded = false
                                scope.launch { languageStore.saveLanguageTag(lang.tag) }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { viewModel.clearMemory() }) {
                Text("Forget recent conversation")
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))

            Text("API keys", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Stored only on this device, sent directly to each provider when you ask a question.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = openAiKey,
                onValueChange = { openAiKey = it },
                label = { Text("OpenAI (ChatGPT) API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = geminiKey,
                onValueChange = { geminiKey = it },
                label = { Text("Google (Gemini) API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Also used for AI video generation",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = claudeKey,
                onValueChange = { claudeKey = it },
                label = { Text("Anthropic (Claude) API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    scope.launch {
                        store.saveOpenAiKey(openAiKey)
                        store.saveGeminiKey(geminiKey)
                        store.saveClaudeKey(claudeKey)
                        personaStore.saveCharacterName(characterName)
                        onBack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }
        }
    }
}
