package com.obsidian.ai.ui

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.obsidian.ai.MainViewModel
import com.obsidian.ai.data.repository.AIResult
import com.obsidian.ai.voice.LanguagePrefStore
import com.obsidian.ai.voice.SpeechController
import com.obsidian.ai.voice.VoiceCommand
import com.obsidian.ai.voice.openAppByName
import com.obsidian.ai.voice.parseVoiceCommand
import com.obsidian.ai.wallpaper.launchCharacterWallpaperPicker

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    onOpenSettings: () -> Unit,
    onOpenVideoGen: () -> Unit,
    onOpenCharacterCreator: () -> Unit
) {
    val context = LocalContext.current
    var prompt by remember { mutableStateOf("") }
    val results by viewModel.results.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    val languageStore = remember { LanguagePrefStore(context) }
    val languageTag by languageStore.languageTag.collectAsState(initial = "en-US")
    val gender by viewModel.personaStore.gender.collectAsState(
        initial = com.obsidian.ai.persona.CharacterGender.MALE
    )

    val speechController = remember { SpeechController(context) }
    DisposableEffect(Unit) {
        onDispose { speechController.destroy() }
    }

    var isListening by remember { mutableStateOf(false) }
    var lastQueryWasVoice by remember { mutableStateOf(false) }

    fun handleVoiceInput(text: String) {
        when (val command = parseVoiceCommand(text)) {
            is VoiceCommand.OpenApp -> {
                val opened = openAppByName(context, command.appName)
                if (!opened) {
                    speechController.speak(
                        "I couldn't find an app called ${command.appName}",
                        languageTag,
                        gender
                    )
                }
            }
            is VoiceCommand.Ask -> {
                prompt = command.question
                lastQueryWasVoice = true
                viewModel.ask(command.question)
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            isListening = true
            speechController.startListening(
                languageTag = languageTag,
                onResult = { text ->
                    isListening = false
                    handleVoiceInput(text)
                },
                onError = { message ->
                    isListening = false
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                }
            )
        } else {
            Toast.makeText(context, "Microphone permission is needed for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    // Speak the first successful answer aloud, but only for voice-triggered
    // questions -- typed questions stay silent so it doesn't talk over you.
    LaunchedEffect(results.size) {
        if (lastQueryWasVoice && results.size == 1) {
            val first = results.first()
            if (first is AIResult.Success) {
                speechController.speak(first.text, languageTag, gender)
            }
            lastQueryWasVoice = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Obsidian AI") },
                actions = {
                    IconButton(onClick = onOpenCharacterCreator) {
                        Icon(Icons.Filled.Face, contentDescription = "Character look")
                    }
                    IconButton(onClick = { launchCharacterWallpaperPicker(context) }) {
                        Icon(Icons.Filled.Wallpaper, contentDescription = "Set as home screen")
                    }
                    IconButton(onClick = onOpenVideoGen) {
                        Icon(Icons.Filled.Movie, contentDescription = "Generate video")
                    }
                    IconButton(onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "Voice input",
                            tint = if (isListening) MaterialTheme.colorScheme.error else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask anything...") },
                    singleLine = false,
                    maxLines = 4
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        lastQueryWasVoice = false
                        viewModel.ask(prompt)
                    },
                    enabled = !isLoading && prompt.isNotBlank()
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Send")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading && results.isEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Asking ChatGPT, Gemini, and Claude...")
                }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(results) { result ->
                    ResultCard(result)
                }
                if (isLoading && results.isNotEmpty()) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Waiting on ${3 - results.size} more...")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResultCard(result: AIResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            when (result) {
                is AIResult.Success -> {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(result.provider, fontWeight = FontWeight.Bold)
                        Text("${result.elapsedMs} ms", style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(result.text)
                }
                is AIResult.Failure -> {
                    Text(result.provider, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        result.error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
