package com.obsidian.ai.character

import android.content.Context
import java.io.File

/**
 * Single fixed location for the current character image, so the live
 * wallpaper (which runs in a separate system-managed process/context) can
 * find whatever was last generated without needing extra plumbing.
 */
object CharacterImageStore {
    fun imageFile(context: Context): File {
        val dir = File(context.filesDir, "character")
        dir.mkdirs()
        return File(dir, "character.png")
    }
}
