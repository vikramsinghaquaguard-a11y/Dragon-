package com.obsidian.ai.data.repository

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class ClaudeRepository(private val client: OkHttpClient) : AIRepository {
    override val providerName = "Claude"

    override suspend fun ask(prompt: String, apiKey: String): AIResult {
        val start = System.currentTimeMillis()
        if (apiKey.isBlank()) return AIResult.Failure(providerName, "No API key set")
        return try {
            val requestBody = JSONObject().apply {
                put("model", "claude-sonnet-4-6")
                put("max_tokens", 1024)
                put(
                    "messages",
                    JSONArray().put(
                        JSONObject().put("role", "user").put("content", prompt)
                    )
                )
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AIResult.Failure(providerName, "HTTP ${response.code}: ${raw.take(200)}")
                }
                val json = JSONObject(raw)
                val text = json.getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                AIResult.Success(providerName, text.trim(), System.currentTimeMillis() - start)
            }
        } catch (e: Exception) {
            AIResult.Failure(providerName, e.message ?: "Unknown error")
        }
    }
}
