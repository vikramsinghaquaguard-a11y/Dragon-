package com.obsidian.ai.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "obsidian_ai_settings")

/**
 * Stores API keys locally on-device only (DataStore / SharedPreferences-like storage).
 * Nothing is ever sent anywhere except directly to the respective provider's API
 * when you ask a question.
 */
class ApiKeyStore(private val context: Context) {

    companion object {
        val OPENAI_KEY = stringPreferencesKey("openai_key")
        val GEMINI_KEY = stringPreferencesKey("gemini_key")
        val CLAUDE_KEY = stringPreferencesKey("claude_key")
    }

    val openAiKey: Flow<String> = context.dataStore.data.map { it[OPENAI_KEY] ?: "" }
    val geminiKey: Flow<String> = context.dataStore.data.map { it[GEMINI_KEY] ?: "" }
    val claudeKey: Flow<String> = context.dataStore.data.map { it[CLAUDE_KEY] ?: "" }

    suspend fun saveOpenAiKey(key: String) {
        context.dataStore.edit { it[OPENAI_KEY] = key }
    }

    suspend fun saveGeminiKey(key: String) {
        context.dataStore.edit { it[GEMINI_KEY] = key }
    }

    suspend fun saveClaudeKey(key: String) {
        context.dataStore.edit { it[CLAUDE_KEY] = key }
    }
}
