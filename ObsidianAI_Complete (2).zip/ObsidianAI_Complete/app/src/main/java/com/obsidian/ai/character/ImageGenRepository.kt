package com.obsidian.ai.character

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val MODEL = "gemini-3.1-flash-image-preview"
private const val URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

class ImageGenRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Generates a character portrait and returns the raw PNG bytes. */
    fun generateCharacterImage(prompt: String, apiKey: String): ByteArray {
        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().put(
                "responseModalities", JSONArray().put("IMAGE").put("TEXT")
            ))
        }.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(URL)
            .addHeader("x-goog-api-key", apiKey)
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("HTTP ${response.code}: ${raw.take(300)}")
            }

            val parts = JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("inlineData")) {
                    val base64Data = part.getJSONObject("inlineData").getString("data")
                    return Base64.decode(base64Data, Base64.DEFAULT)
                }
            }
            throw Exception("No image returned in response")
        }
    }
}
