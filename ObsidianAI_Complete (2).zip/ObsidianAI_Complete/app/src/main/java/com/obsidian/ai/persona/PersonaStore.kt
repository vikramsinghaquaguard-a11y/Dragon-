package com.obsidian.ai.persona

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.personaDataStore by preferencesDataStore(name = "obsidian_ai_persona")

enum class CharacterGender { MALE, FEMALE }

/**
 * Everything here is a *simulated* personality setting -- it changes the
 * tone instruction sent to the AI and which TTS voice speaks, nothing more.
 * It doesn't give the app real feelings or awareness.
 */
class PersonaStore(private val context: Context) {

    companion object {
        private val GENDER = stringPreferencesKey("character_gender")
        private val SHY_MODE = booleanPreferencesKey("shy_mode")
        private val CHARACTER_NAME = stringPreferencesKey("character_name")
    }

    val gender: Flow<CharacterGender> = context.personaDataStore.data.map {
        if (it[GENDER] == "FEMALE") CharacterGender.FEMALE else CharacterGender.MALE
    }

    val shyMode: Flow<Boolean> = context.personaDataStore.data.map { it[SHY_MODE] ?: false }

    val characterName: Flow<String> = context.personaDataStore.data.map { it[CHARACTER_NAME] ?: "Obsidian" }

    suspend fun saveGender(gender: CharacterGender) {
        context.personaDataStore.edit { it[GENDER] = gender.name }
    }

    suspend fun saveShyMode(enabled: Boolean) {
        context.personaDataStore.edit { it[SHY_MODE] = enabled }
    }

    suspend fun saveCharacterName(name: String) {
        context.personaDataStore.edit { it[CHARACTER_NAME] = name }
    }
}

/**
 * Builds the tone instruction prepended to every AI request. This is what
 * makes replies feel like they're coming from "a shy guy" or "a cheerful
 * girl" rather than a generic assistant -- it's a prompt-engineering trick,
 * not an actual personality living in the app.
 */
fun buildPersonaPreamble(name: String, gender: CharacterGender, shy: Boolean): String {
    val genderWord = if (gender == CharacterGender.MALE) "a young man" else "a young woman"
    val tone = if (shy) {
        "You are a little shy and soft-spoken -- keep answers warm but brief, " +
            "and occasionally use gentle, bashful phrasing."
    } else {
        "You are warm, playful, and a bit chatty -- feel free to joke around " +
            "and use casual, friendly language."
    }
    return "You are $name, $genderWord who talks like a close friend, not a formal assistant. $tone " +
        "Keep replies conversational and not overly long."
}
