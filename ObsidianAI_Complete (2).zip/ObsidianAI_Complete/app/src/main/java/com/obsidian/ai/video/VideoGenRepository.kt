package com.obsidian.ai.video

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

// The "Fast" Veo variant -- noticeably cheaper and quicker than the full
// model, good default for an app like this. Swap to "veo-3.1-generate-preview"
// for higher quality at higher cost.
private const val MODEL = "veo-3.1-fast-generate-preview"

sealed class VideoOperationStatus {
    object Pending : VideoOperationStatus()
    data class Done(val videoUri: String) : VideoOperationStatus()
    data class Error(val message: String) : VideoOperationStatus()
}

class VideoGenRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Starts a video generation job. Returns the operation name to poll. */
    fun startGeneration(prompt: String, apiKey: String, aspectRatio: String): String {
        val body = JSONObject().apply {
            put(
                "instances",
                JSONArray().put(JSONObject().put("prompt", prompt))
            )
            put("parameters", JSONObject().put("aspectRatio", aspectRatio))
        }.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("$BASE_URL/models/$MODEL:predictLongRunning")
            .addHeader("x-goog-api-key", apiKey)
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("HTTP ${response.code}: ${raw.take(300)}")
            }
            val name = JSONObject(raw).optString("name")
            if (name.isBlank()) throw Exception("No operation name returned")
            return name
        }
    }

    /** Checks whether a running operation has finished yet. */
    fun pollOperation(operationName: String, apiKey: String): VideoOperationStatus {
        val request = Request.Builder()
            .url("$BASE_URL/$operationName")
            .addHeader("x-goog-api-key", apiKey)
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return VideoOperationStatus.Error("HTTP ${response.code}: ${raw.take(300)}")
            }
            val json = JSONObject(raw)
            val done = json.optBoolean("done", false)
            if (!done) return VideoOperationStatus.Pending

            if (json.has("error")) {
                val err = json.getJSONObject("error")
                return VideoOperationStatus.Error(err.optString("message", "Video generation failed"))
            }

            return try {
                val videoUri = json.getJSONObject("response")
                    .getJSONObject("generateVideoResponse")
                    .getJSONArray("generatedSamples")
                    .getJSONObject(0)
                    .getJSONObject("video")
                    .getString("uri")
                VideoOperationStatus.Done(videoUri)
            } catch (e: Exception) {
                VideoOperationStatus.Error("Couldn't parse the finished response")
            }
        }
    }

    /** Downloads the finished video's bytes from its signed URI. */
    fun downloadVideoBytes(videoUri: String, apiKey: String): ByteArray {
        val request = Request.Builder()
            .url(videoUri)
            .addHeader("x-goog-api-key", apiKey)
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("Download failed: HTTP ${response.code}")
            }
            return response.body?.bytes() ?: throw Exception("Empty video response")
        }
    }
}
