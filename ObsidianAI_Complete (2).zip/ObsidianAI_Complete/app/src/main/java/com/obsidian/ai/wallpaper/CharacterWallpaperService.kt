package com.obsidian.ai.wallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.obsidian.ai.character.CharacterImageStore
import kotlin.math.sin

/**
 * Renders the character as a live wallpaper.
 *
 * If a portrait has been generated (via the "Character Look" screen), it's
 * drawn full-bleed with a slow, subtle breathing zoom -- about as much
 * motion as a still photo can convincingly carry. If no portrait exists
 * yet, falls back to a simple procedurally-drawn placeholder (bouncing
 * circle with eyes) so the wallpaper always shows something.
 */
class CharacterWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = CharacterEngine()

    inner class CharacterEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private var visible = true
        private var frame = 0
        private val frameDelayMs = 33L // ~30fps

        private var characterBitmap: Bitmap? = null
        private var bitmapLoadedForPath: String? = null

        private val bodyPaint = Paint().apply {
            color = Color.parseColor("#7C4DFF")
            isAntiAlias = true
        }
        private val eyeWhitePaint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
        }
        private val pupilPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }
        private val bgPaint = Paint().apply {
            color = Color.parseColor("#121212")
        }
        private val bitmapPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        private val drawRunner = Runnable { draw() }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                handler.post(drawRunner)
            } else {
                handler.removeCallbacks(drawRunner)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(drawRunner)
        }

        private fun loadBitmapIfNeeded() {
            val file = CharacterImageStore.imageFile(applicationContext)
            if (!file.exists()) {
                characterBitmap = null
                bitmapLoadedForPath = null
                return
            }
            // Only decode from disk again if the file actually changed.
            val stamp = "${file.absolutePath}:${file.lastModified()}"
            if (stamp != bitmapLoadedForPath) {
                characterBitmap = BitmapFactory.decodeFile(file.absolutePath)
                bitmapLoadedForPath = stamp
            }
        }

        private fun draw() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    loadBitmapIfNeeded()
                    val bitmap = characterBitmap
                    if (bitmap != null) {
                        drawPortrait(canvas, bitmap)
                    } else {
                        drawPlaceholder(canvas)
                    }
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
            handler.removeCallbacks(drawRunner)
            if (visible) {
                handler.postDelayed(drawRunner, frameDelayMs)
            }
            frame++
        }

        /** Slow "breathing" zoom on the generated portrait -- a Ken Burns effect. */
        private fun drawPortrait(canvas: Canvas, bitmap: Bitmap) {
            val width = canvas.width.toFloat()
            val height = canvas.height.toFloat()
            canvas.drawRect(0f, 0f, width, height, bgPaint)

            val t = frame * 0.01
            // Oscillates the zoom between 1.0x and ~1.06x over roughly a 10s cycle.
            val zoom = 1.03f + sin(t).toFloat() * 0.03f

            val bitmapAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
            val screenAspect = width / height

            // Cover-fit the bitmap to the screen, then apply the zoom on top.
            val baseHeight = if (bitmapAspect > screenAspect) height else width / bitmapAspect
            val baseWidth = baseHeight * bitmapAspect
            val scaledWidth = baseWidth * zoom
            val scaledHeight = baseHeight * zoom

            val left = (width - scaledWidth) / 2f
            val top = (height - scaledHeight) / 2f

            val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
            val destRect = android.graphics.RectF(left, top, left + scaledWidth, top + scaledHeight)
            canvas.drawBitmap(bitmap, srcRect, destRect, bitmapPaint)
        }

        private fun drawPlaceholder(canvas: Canvas) {
            val width = canvas.width.toFloat()
            val height = canvas.height.toFloat()

            canvas.drawRect(0f, 0f, width, height, bgPaint)

            val t = frame * 0.05
            val bounce = sin(t).toFloat() * 12f

            val centerX = width / 2f
            val centerY = height * 0.72f + bounce
            val bodyRadius = width * 0.13f

            canvas.drawCircle(centerX, centerY, bodyRadius, bodyPaint)

            val eyeOffsetX = bodyRadius * 0.4f
            val eyeY = centerY - bodyRadius * 0.15f
            val eyeRadius = bodyRadius * 0.22f
            canvas.drawCircle(centerX - eyeOffsetX, eyeY, eyeRadius, eyeWhitePaint)
            canvas.drawCircle(centerX + eyeOffsetX, eyeY, eyeRadius, eyeWhitePaint)

            val lookX = sin(t * 0.3).toFloat() * eyeRadius * 0.3f
            canvas.drawCircle(centerX - eyeOffsetX + lookX, eyeY, eyeRadius * 0.4f, pupilPaint)
            canvas.drawCircle(centerX + eyeOffsetX + lookX, eyeY, eyeRadius * 0.4f, pupilPaint)
        }
    }
}
