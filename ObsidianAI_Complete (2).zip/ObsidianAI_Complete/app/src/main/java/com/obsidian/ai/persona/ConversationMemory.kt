package com.obsidian.ai.persona

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.memoryDataStore by preferencesDataStore(name = "obsidian_ai_memory")

data class Exchange(val userText: String, val aiText: String)

/**
 * Keeps the last few exchanges on-device so a new question can include
 * "recent conversation" context -- this is what creates the feeling of
 * being remembered. It's a rolling window (oldest dropped first), not a
 * permanent record of everything you've ever said.
 */
class ConversationMemory(private val context: Context) {

    companion object {
        private val HISTORY = stringPreferencesKey("recent_exchanges")
        private const val MAX_EXCHANGES = 6
    }

    suspend fun recentExchanges(): List<Exchange> {
        val raw = context.memoryDataStore.data.first()[HISTORY] ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                Exchange(obj.getString("u"), obj.getString("a"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun addExchange(userText: String, aiText: String) {
        val current = recentExchanges().toMutableList()
        current.add(Exchange(userText, aiText))
        val trimmed = if (current.size > MAX_EXCHANGES) current.takeLast(MAX_EXCHANGES) else current

        val array = JSONArray()
        trimmed.forEach { exchange ->
            array.put(JSONObject().put("u", exchange.userText).put("a", exchange.aiText))
        }
        context.memoryDataStore.edit { it[HISTORY] = array.toString() }
    }

    suspend fun clear() {
        context.memoryDataStore.edit { it[HISTORY] = JSONArray().toString() }
    }

    /** Formats recent exchanges as a short block to prepend to a new prompt. */
    fun formatForPrompt(exchanges: List<Exchange>): String {
        if (exchanges.isEmpty()) return ""
        val lines = exchanges.joinToString("\n") { "User: ${it.userText}\nYou: ${it.aiText}" }
        return "Here's what you two talked about recently:\n$lines\n\nNow continue the conversation naturally.\n\n"
    }
}
