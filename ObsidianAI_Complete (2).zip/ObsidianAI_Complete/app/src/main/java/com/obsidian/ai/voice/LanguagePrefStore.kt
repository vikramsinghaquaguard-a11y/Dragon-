package com.obsidian.ai.voice

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.voiceDataStore by preferencesDataStore(name = "obsidian_ai_voice_settings")

data class VoiceLanguage(val label: String, val tag: String)

val SUPPORTED_LANGUAGES = listOf(
    VoiceLanguage("English (US)", "en-US"),
    VoiceLanguage("Hindi", "hi-IN"),
    VoiceLanguage("Spanish", "es-ES"),
    VoiceLanguage("French", "fr-FR"),
    VoiceLanguage("German", "de-DE"),
    VoiceLanguage("Arabic", "ar-SA"),
    VoiceLanguage("Japanese", "ja-JP")
)

class LanguagePrefStore(private val context: Context) {
    companion object {
        private val LANGUAGE_TAG = stringPreferencesKey("voice_language_tag")
    }

    val languageTag: Flow<String> = context.voiceDataStore.data.map { it[LANGUAGE_TAG] ?: "en-US" }

    suspend fun saveLanguageTag(tag: String) {
        context.voiceDataStore.edit { it[LANGUAGE_TAG] = tag }
    }
}
