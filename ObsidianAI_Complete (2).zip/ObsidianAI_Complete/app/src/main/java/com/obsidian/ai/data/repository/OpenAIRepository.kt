package com.obsidian.ai.data.repository

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class OpenAIRepository(private val client: OkHttpClient) : AIRepository {
    override val providerName = "ChatGPT"

    override suspend fun ask(prompt: String, apiKey: String): AIResult {
        val start = System.currentTimeMillis()
        if (apiKey.isBlank()) return AIResult.Failure(providerName, "No API key set")
        return try {
            val requestBody = JSONObject().apply {
                put("model", "gpt-4o-mini")
                put(
                    "messages",
                    JSONArray().put(
                        JSONObject().put("role", "user").put("content", prompt)
                    )
                )
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AIResult.Failure(providerName, "HTTP ${response.code}: ${raw.take(200)}")
                }
                val json = JSONObject(raw)
                val text = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                AIResult.Success(providerName, text.trim(), System.currentTimeMillis() - start)
            }
        } catch (e: Exception) {
            AIResult.Failure(providerName, e.message ?: "Unknown error")
        }
    }
}
