package com.obsidian.ai.character

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.obsidian.ai.data.ApiKeyStore
import com.obsidian.ai.persona.CharacterGender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class ImageGenState {
    object Idle : ImageGenState()
    object Generating : ImageGenState()
    data class Success(val filePath: String) : ImageGenState()
    data class Error(val message: String) : ImageGenState()
}

class ImageGenViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ImageGenRepository()
    private val apiKeyStore = ApiKeyStore(application)

    private val _state = MutableStateFlow<ImageGenState>(ImageGenState.Idle)
    val state: StateFlow<ImageGenState> = _state

    fun generate(gender: CharacterGender, styleDescription: String) {
        _state.value = ImageGenState.Generating

        viewModelScope.launch {
            try {
                val apiKey = apiKeyStore.geminiKey.first()
                if (apiKey.isBlank()) {
                    _state.value = ImageGenState.Error("Add your Gemini API key in Settings first")
                    return@launch
                }

                val genderWord = if (gender == CharacterGender.MALE) "young man" else "young woman"
                val extra = if (styleDescription.isBlank()) "" else " $styleDescription."
                val prompt = "A friendly, warm portrait of a $genderWord character, front-facing, " +
                    "head and shoulders, simple plain background, clean digital illustration style, " +
                    "approachable and expressive face.$extra"

                val bytes = withContext(Dispatchers.IO) {
                    repository.generateCharacterImage(prompt, apiKey)
                }

                val file = CharacterImageStore.imageFile(getApplication())
                withContext(Dispatchers.IO) {
                    file.writeBytes(bytes)
                }

                _state.value = ImageGenState.Success(file.absolutePath)
            } catch (e: Exception) {
                _state.value = ImageGenState.Error(e.message ?: "Something went wrong")
            }
        }
    }

    fun reset() {
        _state.value = ImageGenState.Idle
    }
}
