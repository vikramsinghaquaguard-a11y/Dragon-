package com.obsidian.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import com.obsidian.ai.persona.CharacterGender
import java.util.Locale

/**
 * Wraps Android's built-in speech recognizer (listening) and TextToSpeech
 * (speaking) -- both free, no external API key needed.
 */
class SpeechController(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false

    init {
        textToSpeech = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
    }

    fun startListening(languageTag: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition isn't available on this device")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                if (text.isNullOrBlank()) {
                    onError("Didn't catch that")
                } else {
                    onResult(text)
                }
            }

            override fun onError(error: Int) {
                onError("Recognition error ($error)")
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
    }

    /**
     * Speaks text using a voice matched to the chosen character gender.
     *
     * Android doesn't have an official "gender" field on Voice, so this
     * uses a best-effort heuristic (voice name/locale hints). Accuracy
     * depends on the phone manufacturer and installed TTS engine -- some
     * devices offer clearly labeled male/female voices, others don't
     * distinguish at all, in which case this falls back to the default
     * voice for the language.
     */
    fun speak(text: String, languageTag: String, gender: CharacterGender) {
        if (!ttsReady) return
        val tts = textToSpeech ?: return
        val locale = Locale.forLanguageTag(languageTag)
        tts.language = locale

        val matchedVoice = findVoiceForGender(tts.voices, locale, gender)
        if (matchedVoice != null) {
            tts.voice = matchedVoice
        }

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "obsidian_ai_utterance")
    }

    private fun findVoiceForGender(voices: Set<Voice>?, locale: Locale, gender: CharacterGender): Voice? {
        if (voices.isNullOrEmpty()) return null
        val sameLanguage = voices.filter { it.locale.language == locale.language }
        if (sameLanguage.isEmpty()) return null

        val genderHints = if (gender == CharacterGender.FEMALE) {
            listOf("female", "woman", "f#", "-f-")
        } else {
            listOf("male", "man", "m#", "-m-")
        }

        return sameLanguage.firstOrNull { voice ->
            val name = voice.name.lowercase()
            genderHints.any { hint -> name.contains(hint) }
        } ?: sameLanguage.firstOrNull()
    }

    fun destroy() {
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}
