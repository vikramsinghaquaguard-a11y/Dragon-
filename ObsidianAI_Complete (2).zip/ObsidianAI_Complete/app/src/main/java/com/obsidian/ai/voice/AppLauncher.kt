package com.obsidian.ai.voice

import android.content.Context
import android.content.Intent

/**
 * Finds an installed app whose visible label roughly matches the spoken
 * name and launches it. Requires the <queries> block in AndroidManifest.xml
 * (see voice_changes.txt) so the app can see other installed apps'
 * launcher entries on Android 11+.
 *
 * Returns true if a matching app was found and launched.
 */
fun openAppByName(context: Context, spokenName: String): Boolean {
    val pm = context.packageManager
    val launchables = pm.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
        0
    )

    val normalizedSpoken = spokenName.trim().lowercase()
    if (normalizedSpoken.isBlank()) return false

    val match = launchables.firstOrNull { resolveInfo ->
        val label = resolveInfo.loadLabel(pm).toString().lowercase()
        label == normalizedSpoken || label.contains(normalizedSpoken) || normalizedSpoken.contains(label)
    }

    val packageName = match?.activityInfo?.packageName ?: return false
    val launchIntent = pm.getLaunchIntentForPackage(packageName) ?: return false

    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(launchIntent)
    return true
}
