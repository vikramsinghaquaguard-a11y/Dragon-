package com.obsidian.ai.data.repository

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GeminiRepository(private val client: OkHttpClient) : AIRepository {
    override val providerName = "Gemini"

    override suspend fun ask(prompt: String, apiKey: String): AIResult {
        val start = System.currentTimeMillis()
        if (apiKey.isBlank()) return AIResult.Failure(providerName, "No API key set")
        return try {
            val requestBody = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    )
                )
            }.toString().toRequestBody("application/json".toMediaType())

            val url =
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AIResult.Failure(providerName, "HTTP ${response.code}: ${raw.take(200)}")
                }
                val json = JSONObject(raw)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                AIResult.Success(providerName, text.trim(), System.currentTimeMillis() - start)
            }
        } catch (e: Exception) {
            AIResult.Failure(providerName, e.message ?: "Unknown error")
        }
    }
}
