package com.obsidian.ai.voice

sealed class VoiceCommand {
    data class OpenApp(val appName: String) : VoiceCommand()
    data class Ask(val question: String) : VoiceCommand()
}

private val openAppPrefixes = listOf("open ", "launch ", "start ")

fun parseVoiceCommand(text: String): VoiceCommand {
    val lower = text.trim().lowercase()
    for (prefix in openAppPrefixes) {
        if (lower.startsWith(prefix)) {
            val appName = text.trim().substring(prefix.length).trim()
            if (appName.isNotBlank()) {
                return VoiceCommand.OpenApp(appName)
            }
        }
    }
    return VoiceCommand.Ask(text)
}
