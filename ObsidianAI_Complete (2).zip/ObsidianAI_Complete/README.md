# Obsidian AI — Complete Setup Guide

Everything built so far, in one project:
- Login (email/password + Google sign-in)
- Chat with ChatGPT, Gemini, and Claude at once — fastest answer shown first
- A character with a chosen gender and personality (playful or shy), whose
  voice matches its gender when it speaks
- An AI-generated character portrait (Nano Banana 2) that becomes your
  home screen wallpaper, with a subtle breathing zoom animation
- Short-term conversation memory, so it feels like it remembers your last
  few exchanges
- Voice input — talk to it, or say "open [app name]" to launch an app
- AI video generation (Veo)

**Read the honesty note first:** the "personality," "memory," and "emotion"
here are all simulated through prompt text and a rolling chat log — not
real awareness or feelings. Worth keeping in mind, especially if this is
meant to feel like a companion.

---

## Building this with only a phone (no computer)

This project now includes everything needed to build in the cloud via
**GitHub Actions** — GitHub's free build servers — entirely from your
phone's browser. No Android Studio required for this path.

### Step 1: Create a GitHub account
Go to github.com in your phone's browser → sign up (free).

### Step 2: Create a new repository
Tap the **+** icon → **New repository**. Name it anything (e.g.
`obsidian-ai`). Set it to **Private** (recommended, since you'll be
uploading API keys later). Create it.

### Step 3: Upload this project's files
On your new repo's page: **Add file → Upload files**. Upload the
`ObsidianAI_Complete.zip` you downloaded — GitHub will let you upload the
zip directly, but you actually need the *extracted contents* at the
repo's root (not the zip itself sitting inside the repo). The most
reliable way to do this on a phone:

1. Use a file manager app on your phone (most phones have one built in,
   or install a free one) to **extract/unzip** `ObsidianAI_Complete.zip`
   first
2. Go back to GitHub's upload page, and upload the extracted folder's
   contents — most mobile file managers let you select multiple files
   and folders at once for the upload picker
3. Make sure the result on GitHub shows `app/`, `.github/`,
   `settings.gradle.kts`, etc. sitting directly in the repo root — not
   nested inside another `ObsidianAI_Complete` folder

### Step 4: Set up Firebase (required for login to work)
Follow the "Set up Firebase" section below, still entirely in your phone
browser. The one extra step here: after downloading `google-services.json`
from Firebase, upload it into your GitHub repo at the exact path
`app/google-services.json` (Add file → Upload files again, navigate into
the `app` folder first).

### Step 5: Add your API keys as GitHub Secrets (optional, safer than
hardcoding)
Actually — for this project, API keys are entered inside the app itself
(Settings screen) after it's installed, not baked into the build. So you
can skip straight to building.

### Step 6: Trigger the build
In your repo: tap **Actions** tab → you should see "Build APK" listed →
tap it → **Run workflow** → **Run workflow** (green button). Wait a few
minutes (GitHub is compiling everything on their servers).

### Step 7: Download the APK
Once the run shows a green checkmark, tap into it → scroll down to
**Artifacts** → tap `obsidian-ai-debug-apk` to download it as a zip →
extract it to get `app-debug.apk`.

### Step 8: Install it on your phone
Open the downloaded `app-debug.apk` file (from your Downloads/Files app).
Android will likely block it the first time with "install blocked" —
tap **Settings** in that prompt, enable **Allow from this source** for
your browser/file manager app, go back, and tap Install.

This APK is unsigned/"debug" — perfectly fine to install and run on your
own phone, just not something you'd publish to the Play Store as-is.

---

## Building this with a computer (Android Studio) — alternative path

If you get access to a computer later, this is the more comfortable way
to keep developing it further:

---

## 1. Create the project in Android Studio

1. **New Project → Empty Activity** (the Compose template)
2. Name: `Obsidian AI`, package: `com.obsidian.ai`, min SDK: **26**, language: **Kotlin**
3. Delete the sample `MainActivity.kt` it generates

## 2. Copy in every file

Copy the entire `app/src/main/java/com/obsidian/ai/` folder from this
package into your project, preserving the folder structure exactly:

```
com/obsidian/ai/
  MainActivity.kt
  MainViewModel.kt
  auth/AuthViewModel.kt
  data/ApiKeyStore.kt
  data/repository/AIRepository.kt
  data/repository/OpenAIRepository.kt
  data/repository/GeminiRepository.kt
  data/repository/ClaudeRepository.kt
  persona/PersonaStore.kt
  persona/ConversationMemory.kt
  character/ImageGenRepository.kt
  character/ImageGenViewModel.kt
  character/CharacterImageStore.kt
  voice/SpeechController.kt
  voice/AppLauncher.kt
  voice/CommandParser.kt
  voice/LanguagePrefStore.kt
  video/VideoGenRepository.kt
  video/VideoGenViewModel.kt
  wallpaper/CharacterWallpaperService.kt
  wallpaper/WallpaperLauncher.kt
  ui/LoginScreen.kt
  ui/ChatScreen.kt
  ui/SettingsScreen.kt
  ui/VideoGenScreen.kt
  ui/CharacterCreatorScreen.kt
```

Also copy these resource files into `app/src/main/res/`:
- `xml/character_wallpaper.xml`
- `xml/file_paths.xml`
- `drawable/wallpaper_thumbnail.xml`

Replace `app/src/main/AndroidManifest.xml` entirely with the one included
here.

## 3. Gradle is already set up

Unlike earlier versions of this project, `settings.gradle.kts`,
`build.gradle.kts`, and `app/build.gradle.kts` are already included and
ready to use — copy them into your Android Studio project as-is (Android
Studio will likely ask to overwrite the ones it auto-generated; say yes).

## 4. Set up Firebase (needed for login)

1. console.firebase.google.com → **Add project**
2. **Add app → Android**, package name `com.obsidian.ai`
3. Download `google-services.json` → place it at `app/google-services.json`
4. **Build → Authentication → Sign-in method** → enable **Email/Password**
   and **Google**
5. Copy the **Web client ID** shown under Google's settings
6. In Android Studio, **Gradle panel → app → Tasks → android →
   signingReport**, copy the `SHA1` value, and add it in Firebase console
   → Project settings → your app → Add fingerprint
7. In `AuthViewModel.kt`, replace:
   ```
   private val webClientId = "PASTE_YOUR_FIREBASE_WEB_CLIENT_ID_HERE"
   ```
   with the Web client ID from step 5

## 5. Sync, build, and run

**Sync Now** → **Build → Make Project** → fix any red underlines (usually
just missing imports, Alt+Enter handles most) → **Run ▶**

## 6. Using the app

1. **Log in** (create an account, or use Google sign-in)
2. Tap **Settings** (gear icon):
   - Name your character and pick **Male** or **Female** — this sets both
     the personality tone in text replies and which TTS voice speaks
   - Toggle **Shy personality** if you want softer, shorter replies
   - Pick a language for voice input/output
   - Add your API keys (see below)
3. Back on the chat screen:
   - Type or tap the **mic** icon to talk
   - Tap the **face** icon to generate your character's look (pick gender,
     optionally describe a style), then tap **Set as home screen character**
   - Tap the **movie** icon to generate an AI video

## API keys you'll need (all optional, add what you want to use)

- **OpenAI**: platform.openai.com → API keys (needs billing)
- **Gemini**: aistudio.google.com → Get API key (free tier available;
  also powers character image generation and AI video generation, both
  of which need billing enabled)
- **Claude**: console.anthropic.com → API Keys (needs billing)

## Known limitations, all still true

- The home screen character is a real AI-generated portrait now (once you
  generate one), animated with a slow breathing zoom — it isn't a moving,
  talking, fully animated avatar. True real-time lip-sync/facial animation
  on a live photo is a much bigger project (a dedicated animation engine),
  well beyond what a wallpaper service can reasonably do.
- Gendered TTS voice quality depends on your phone — some devices have
  clearly distinct male/female voices installed, others don't.
- The phone cannot be shut down by voice command on any regular Android
  app — this is an OS-level restriction, not a limitation of this code.
- Conversation memory is a rolling window of your last 6 exchanges, kept
  only on your device — not a permanent transcript of everything you've
  ever said. "Remembers you" is a simulated effect, not real recall.
- Video generation costs roughly $0.10–$0.40 per second; character images
  are a few cents each — both billed to your own Google account.
